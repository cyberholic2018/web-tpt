<?php $__env->startSection('custom-style'); ?>
    <link rel="stylesheet" type="text/css" href="/js/plugins/slider/engine1/style.css" />
    <style media="screen">
        <?php $__currentLoopData = $ithomeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            .ithome0<?php echo e($key); ?> {
                background-image: url('<?php echo e($value['featureImage']); ?>');
            }
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js-script'); ?>
    <script type="text/javascript" src="js/plugins/slider/engine1/wowslider.js"></script>
    <script type="text/javascript" src="js/plugins/slider/engine1/script.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12" style="padding: 0; overflow:hidden">
            <div id="wowslider-container1">
                <div class="ws_images">
                    <ul>
                        <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><img src="<?php echo e($item->url); ?>" alt="<?php echo e($item->title); ?>" title="<?php echo e($item->title); ?>"/></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="ws_bullets">
                    <div>
                        <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="#" title="<?php echo e($item->title); ?>"><span><img height="48" src="<?php echo e($item->url); ?>" alt="<?php echo e($item->title); ?>"/>1</span></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="ws_shadow"></div>
            </div>
        </div>

        <div class="container">
            <div class="col-md-4 solution-section">
                <div class="solution-header product">
                </div>
                <div class="solution-info">
                    <h3><?php echo trans('string.product_info'); ?></h3>
                    <a href="/product/<?php echo e(CategoryView::type('product')[0]->guid); ?>"><?php echo trans('string.product_info_sub'); ?></a>
                </div>
            </div>

            <div class="col-md-4 solution-section">
                <div class="solution-header solution">
                </div>
                <div class="solution-info">
                    <h3><?php echo trans('string.solution'); ?></h3>
                    <a href="<?php echo e(url('/solution-education')); ?>"><?php echo trans('string.solution_sub'); ?></a>
                </div>
            </div>

            <div class="col-md-4 solution-section">
                <div class="solution-header partner">
                </div>
                <div class="solution-info">
                    <h3><?php echo trans('string.partners'); ?></h3>
                    <a href="<?php echo e(url('/partners')); ?>"><?php echo trans('string.partners_sub'); ?></a>
                </div>
            </div>
        </div>

        <?php if(App::getLocale() === 'zh-TW'): ?>

        <?php endif; ?>
        <div class="container-fluid">
            <div class="row">
                <?php $__currentLoopData = $ithomeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 news-section">
                        <div class="zoom-bg ithome0<?php echo e($key); ?>"></div>
                        <div class="news-info">
                            <h2><a target="_blank" href="<?php echo e($value['link']); ?>"><?php echo e($value['title']); ?></a></h2>
                            <h3 class="hash-tag">#iTHome</h3>
                            <span><?php echo e($value["pubDate"]); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 learn-more-news">
                    <a href="/news"><?php echo trans('string.review_news'); ?></a>
                </div>
            </div>
        </div>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>