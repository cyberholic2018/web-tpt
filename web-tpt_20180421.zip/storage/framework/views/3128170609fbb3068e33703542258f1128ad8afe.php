<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="page-contant-header about">
                <h2><?php echo e($contentTitle); ?></h2>
            </div>
            <div class="page-thumbnail">
                <span class="glyphicon glyphicon-home" aria-hidden="true"></span>
                <span>></span>
                <span>Resource Center</span>
                <span>></span>
                <span><?php echo e($contentTitle); ?></span>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <ul class="page-side-menu">
                <li><a class="<?php echo e($active01); ?>" href="/resource/certificates">Certificates</a></li>
                <li><a class="<?php echo e($active02); ?>" href="/resource/manuals">Manuals</a></li>
                <li><a class="<?php echo e($active03); ?>" href="/resource/driversnsoftwares">Drivers & Softwares</a></li>
            </ul>
        </div>
        <div class="col-md-9 sub-page-content">
            <?php echo $__env->yieldContent('sub-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>