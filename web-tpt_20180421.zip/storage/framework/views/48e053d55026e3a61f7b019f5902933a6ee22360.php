<!doctype html>
<html class="no-js">
  <head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title); ?></title>

    <link rel="shortcut icon" href="<?php echo e($shortcut); ?>">


    <link rel="stylesheet" href="/styles/vendor.css">

    <link rel="stylesheet" href="/css/frontend.css">

    <link rel="stylesheet" href="/styles/main.css">

    <link rel="stylesheet" type="text/css" href="/js/plugins/slider/engine1/style.css" />

    <script src="/scripts/vendor/modernizr.js"></script>
    <?php echo $__env->yieldContent('custom-style'); ?>
  </head>
  <body>
      <div class="loading-bar">
          <img src="/img/icon/loading-bar.svg" alt="">
      </div>
    <!--[if IE]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <?php echo $__env->yieldContent('custom-header'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="row">
                    <div class="col-md-8 index-header">
                        <div class="page-header">
                            <h1>
                                <a href="/"><img class="index-logo" src="/images/fidelity-logo.png" alt="恆準"></a>
                            </h1>
                        </div>
                        <div id="nav-btn" class="">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                    <div class="col-md-4 index-header-search">
                        <table>
                            <tr>
                                <td colspan="2" align="right" style="padding-bottom: 90px">

                                    
                                </td>
                            </tr>
                            
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-default netone-nav" role="navigation">
                            <div class="navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav">
                                    <li>
                                        <a href="/">Home</a>
                                    </li>
                                    <li>
                                        <a href="/about">About us</a>
                                    </li>
                                    <li>
                                        <a href="/news">News & Information</a>
                                    </li>
                                    <li>
                                        <a href="/product">Products</a>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Resource Center&nbsp;<strong class="caret"></strong></a>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a href="/resource/certificates">Certificates</a>
                                            </li>
                                            <li>
                                                <a href="/resource/manuals">Manuals</a>
                                            </li>
                                            <li>
                                                <a href="/resource/driversnsoftwares">Drivers & Softwares</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="/videos">Videos</a>
                                    </li>
                                    <li>
                                        <a href="/tutorials">Tutorials</a>
                                    </li>
                                </ul>


                                <ul class="nav navbar-nav navbar-right">

                                </ul>
                            </div>

                        </nav>
                        
                    </div>
                </div>

                <?php echo $__env->yieldContent('content'); ?>



                <div class="row">
                    <div class="col-md-12">
                        <div class="row index-section footer">
                            <div class="col-md-12">
                                <ul class="footer-menu pull-right">
                                    <li><a href="/contact">Contact Us</a></li>
                                    <li><a href="/legalthings">Privacy, Terms & Conditions</a></li>
                                    <li><a href="/links">Friendly Links</a></li>
                                    <li><a href="/sitemap">Sitemap</a></li>
                                </ul>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-md-12" style="padding: 5px; text-align: center">
                        <p>© Copyright 2012-2014 Fidelity Measurement Company Limited All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <script src="/scripts/vendor.js"></script>

    <script src="<?php echo e(asset('js/all.js')); ?>"></script>

    <script src="/scripts/plugins.js"></script>

    <script src="/scripts/main.js"></script>

    <?php echo $__env->yieldContent('custom-js-script'); ?>

    <?php if(config('app.env') == 'local'): ?>
        <script src="http://localhost:35729/livereload.js"></script>
    <?php endif; ?>
  </body>
</html>
