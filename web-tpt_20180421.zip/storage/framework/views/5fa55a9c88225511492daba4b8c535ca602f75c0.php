<?php $__env->startSection('custom-style'); ?>
    <style media="screen">
        .page-content-header {
            background-image: url('/images/sunrise-1756274_1920.jpg');
        }
        #facebook-share, #line-share {
        cursor: pointer;
        }
        /* .page-content-header {
            background-image: url('/images/sunrise-1756274_1920.jpg');

        } */
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js-script'); ?>
    <?php echo $__env->yieldContent('sub-script'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-header'); ?>
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/zh_TW/sdk.js#xfbml=1&version=v2.10&appId=124798941401730";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 page-content">
            <div class="page-content-header">
                <h2><?php echo trans('header.success_case'); ?></h2>
            </div>
        </div>
    </div>
    <div class="row">
        
        <div class="col-md-12 sub-page-content">
            <?php echo $__env->yieldContent('sub-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>