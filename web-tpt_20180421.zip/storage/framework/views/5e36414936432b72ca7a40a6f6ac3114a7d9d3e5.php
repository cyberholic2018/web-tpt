<?php $__env->startSection('sub-content'); ?>
    <?php echo json_decode($pageContent->content)->content; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.no-sidebar.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>