<?php $__env->startSection('sub-script'); ?>
    <script src="/js/partner.js" charset="utf-8"></script>
    <script>
        // var map;
        window.initGoogleMap = function () {
            initMap();
        };

        function initMap() {
            var features = window.feature;

            if (!features) {
                return;
            }

            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 14,
                center: features[0].position,
                mapTypeId: 'roadmap'
            });

            var iconBase = '/img/icon/';
            var icons = {
                location: {
                    icon: iconBase + 'icon-teardrop-cyan.png'
                }
            };

            var lastInfowindow;            

            // Create markers.
            features.forEach(function(feature) {
                var marker = new google.maps.Marker({
                    position: feature.position,
                    icon: icons[feature.type].icon,
                    map: map
                });

                var contentString = '<div class="map-content">' +
                    '<h3 style="margin-top: 11px;">' + feature.name + '</h3>' +
                    '<h4>' + feature.addressString + '</h4>' +
                    '<a href="' + feature.link + '" target="_blank">' + feature.link + '</a>' +
                    '</div>';

                var infowindow = new google.maps.InfoWindow({
                    content: contentString
                });

                marker.addListener('click', function() {
                    if (lastInfowindow) {
                        lastInfowindow.close();
                    }

                    infowindow.close();
                    infowindow.setContent(contentString);
                    map.panTo(marker.getPosition());
                    infowindow.open(map, marker);
                    lastInfowindow = infowindow;
                });

                setTimeout(function () {
                    $('.map-btn').on('click', function() {
                        var mapId = $(this).attr('id');

                        if (feature.id === mapId) {

                            if (lastInfowindow) {
                                lastInfowindow.close();
                            }

                            infowindow.close();
                            infowindow.setContent(contentString);
                            map.panTo(marker.getPosition());
                            infowindow.open(map, marker);
                            lastInfowindow = infowindow;
                        }
                    });
                }, 50);


            });

        }
    </script>

    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBWGyWQEgeR_KqcgTOAuUaGe4BmmnclGzs&callback=initMap" type="text/javascript"></script>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('sub-content'); ?>

    <div class="row" id="partner">
        <input type="hidden" id="partner_finder" name="" value="<?php echo trans('string.partner_finder'); ?>">
        <input type="hidden" id="partner_finder_choose" name="" value="<?php echo trans('string.partner_finder_choose'); ?>">
        <input type="hidden" id="partner_finder_country" name="" value="<?php echo trans('string.partner_finder_country'); ?>">
        <div class="col-md-12">
            <partner></partner>
        </div>

        
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.partners.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>