<?php $__env->startSection('custom-js-script'); ?>
<script src="<?php echo e(asset('js/reset-password.js')); ?>"></script>
<script type="text/javascript">
    $('.loading-bar').fadeOut('100');
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel-content'); ?>
<div class="row" id="resetPassword">
    <?php if($currentUser->socialUser): ?>
        <div class="col-md-12">
            <div class="alert alert-warning" role="alert">
                社群使用者無法使用重置密碼功能
            </div>
        </div>
    <?php else: ?>
        <resetpassword></resetpassword>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>