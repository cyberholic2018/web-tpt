<?php $__env->startSection('sub-script'); ?>
    <script type="text/javascript">
        function showYoutube(url) {
            document.getElementById(url).src = "https://www.youtube.com/embed/" + url;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-content'); ?>
    <div class="row">
        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 video-info" data-toggle="modal" data-target="#<?php echo e($item->guid); ?>" onclick="showYoutube('<?php echo e(str_replace("https://www.youtube.com/embed/", "", $item->url)); ?>')">
                <img wid src="<?php echo e("https://img.youtube.com/vi/".str_replace("https://www.youtube.com/embed/", "", $item->url)."/hqdefault.jpg"); ?>" alt="">

                <div class="play-button">
                    <span class="glyphicon glyphicon-play"></span>
                </div>
            </div>

            <!-- Modal -->
            <div class="modal fade video-modal" id="<?php echo e($item->guid); ?>" role="dialog">
                <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title"><?php echo e($item->title); ?></h4>
                        </div>
                        <div class="modal-body">
                            <div class="embed-responsive embed-responsive-16by9">
                                <iframe class="embed-responsive-item" id="<?php echo e(str_replace("https://www.youtube.com/embed/", "", $item->url)); ?>" allowfullscreen></iframe>
                            </div>
                            <br>
                            <h4><strong>Details</strong></h4>
                            <hr>
                            <div class="video-description">
                                <?php echo $item->description; ?>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.video.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>