<?php $__env->startSection('custom-js-script'); ?>
<script src="<?php echo e(asset('js/backend/item-list.js')); ?>" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel-content'); ?>
<div class="row ch-product-form" id="item-list">
    <div class="col-md-12">
        <item-list></item-list>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>