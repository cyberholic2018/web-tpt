<?php $__env->startSection('sub-script'); ?>
    <script src="/js/plugins/masonry/masonry.pkgd.min.js" charset="utf-8"></script>
    <script src="/js/plugins/mp/mp.mansory.min.js" charset="utf-8"></script>
    <script type="text/javascript">
    $('.grid').masonry({
        itemSelector: '.grid-item',
    });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-content'); ?>
    <div class="row" id="netone-news">
        <div class="col-md-8 col-md-offset-2 about-content" style="margin-top: 30px; margin-bottom: 50px;">
            <br>
            


            <div class="grid">
                <?php $__currentLoopData = PostView::success(App::getLocale()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="grid-item">
                        <div class="success-case">
                            <div class="success-img">
                                <img src="<?php echo e($item->featureImage); ?>" alt="">
                                <h3><?php echo e($item->title); ?></h3>
                            </div>
                            <div class="success-content">
                                <?php echo $item->content; ?>

                            </div>
                            <div class="success-footer">
                                <a class="btn btn-default" href="/news/<?php echo e($item->guid); ?>"><?php echo trans('string.learn_more'); ?></a>
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e(PostView::success(App::getLocale())); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.success.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>