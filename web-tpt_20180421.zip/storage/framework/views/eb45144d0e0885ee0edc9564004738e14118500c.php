<?php $__env->startSection('custom-js-script'); ?>>
    <script src="<?php echo e(asset('js/backend/add-post.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel-content'); ?>
    <div class="row ch-post-form" id="addPost">
        <div class="col-md-12">
            <?php if($mode == 'edit'): ?>
                <input id="row-guid" type="hidden" name="" value="<?php echo e($guid); ?>">
            <?php endif; ?>
            <addpost></addpost>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>