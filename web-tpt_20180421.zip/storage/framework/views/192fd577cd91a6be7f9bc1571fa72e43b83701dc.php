<!doctype html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(SiteMetaView::title()); ?></title>

        <link rel="shortcut icon" href="<?php echo e(SiteMetaView::shortcut()); ?>">

        <link rel="stylesheet" href="/css/frontend.css">

        <link rel="stylesheet" href="/css/fontawesome-all.min.css">

        <link rel="stylesheet" href="/js/plugins/slick/slick.css">

        <link rel="stylesheet" href="/css/fa/css/font-awesome.min.css">

        <script src="/js/vendor/modernizr.js"></script>

        <?php echo $__env->yieldContent('custom-style'); ?>

    </head>
    <body>
        <div class="loading-bar">
            <img src="/img/icon/loading-bar.svg" alt="">
        </div>

        <?php echo $__env->yieldContent('custom-header'); ?>

        <div class="container">
            <div class="row social-header">


                
            </div>
            <div class="row site-header">
                <ul class="lang-list">
                    <?php $__currentLoopData = Config::get('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($lang != App::getLocale()): ?>
                            <li><a style="color: #aaa; font-weight: light; margin-top: 5px; text-decoration: none" href="<?php echo e(route('lang.switch', $lang)); ?>"><?php echo e($language); ?></a></li>
                        <?php else: ?>
                            <li><a style="color: #004471; font-weight: bolder; margin-top: 5px; text-decoration: none" href="<?php echo e(route('lang.switch', $lang)); ?>"><?php echo e($language); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div id="logo-section" class="col-md-3">
                    <div class="site-logo">
                        <a href="/">
                            <img src="/images/index_logo-en.svg" alt="">
                        </a>
                    </div>
                    <div id="nav-btn" class="">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
                <div id="nav-section" class="col-md-9">
                    <nav class="site-nav pull-right">
                        <img class="nav-logo" src="/images/index_logo-en.png" alt="">
                        <ul>
                            <li>
                                <a href="#"><?php echo trans('header.product'); ?>

                                    <?php if(count(CategoryView::type('product')) > 0): ?>
                                        &nbsp;&nbsp;<i class="fa fa-angle-down" aria-hidden="true"></i>
                                    <?php endif; ?>
                                </a>
                                <?php if(CategoryView::type('product')): ?>
                                    <ul>
                                        <?php $__currentLoopData = CategoryView::type('product'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="/product/<?php echo e($item->guid); ?>"><?php echo e($item->title); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                            <li>
                                <a href="#"><?php echo trans('header.solution'); ?>&nbsp;&nbsp;<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                <?php if(App::getLocale() == 'zh-TW'): ?>
                                    <ul>
                                        <li><a href="/solution-education">教育校園</a></li>
                                        <li><a href="/solution-government">政府機關</a></li>
                                        <li><a href="/solution-enterprise">企業製造業</a></li>
                                        <li><a href="/solution-ap">UAC無線網路整合</a></li>
                                    </ul>
                                <?php else: ?>
                                    <ul>
                                        <li><a href="/solution-education">Education</a></li>
                                        <li><a href="/solution-government">Government</a></li>
                                        <li><a href="/solution-enterprise">Enterprise</a></li>
                                        <li><a href="/solution-ap">UAC</a></li>
                                    </ul>
                                <?php endif; ?>
                            </li>
                            <li><a href="<?php echo e(url('/partners')); ?>"><?php echo trans('header.partner'); ?></a></li>
                            <li>
                                <a href="#"><?php echo trans('header.support'); ?>&nbsp;&nbsp;<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                <ul>
                                    <li><a href="<?php echo e(url('/repair')); ?>"><?php echo trans('header.repair'); ?></a></li>
                                    <li><a href="<?php echo e(url('/qna')); ?>"><?php echo trans('header.qna'); ?></a></li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(url('/about')); ?>"><?php echo trans('header.about'); ?></a></li>
                            <li><a href="<?php echo e(url('/news')); ?>"><?php echo trans('header.news'); ?></a></li>
                            <li><a href="<?php echo e(url('/success')); ?>"><?php echo trans('header.success_case'); ?></a></li>
                            <li><a href="<?php echo e(url('/bidding')); ?>"><?php echo trans('header.bidding_project'); ?></a></li>
                        </ul>
                        <div class="social-section">
                            <a href="#">
                                <img width="30" src="/images/location_icon-01-01_b.png" alt="">
                            </a>
                            <a href="#">
                                <img width="30" src="/images/search_icon-01-01-01_b.png" alt="">
                            </a>
                            <a href="#">
                                <img width="30" src="/images/mail_icon-01-01-01_b.png" alt="">
                            </a>
                            <a href="#">
                                <img width="30" src="/images/call_icon-01-01_b.png" alt="">
                            </a>
                            <a href="#">
                                <img width="30" src="/images/mylove_icon-01-01_b.png" alt="">
                            </a>
                            <a href="#">
                                <img width="30" src="/images/fb_icon-01-01-01_b.png" alt="">
                            </a>
                        </div>
                    </nav>
                </div>
            </div>


        </div>

        <div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <div class="container-fluid footer-section">
            <div class="row">
                <div class="container">
                    <div class="row footer-row">
                        <div class="col-md-4 footer-info">
                            <h3><?php echo trans('header.product'); ?></h3>
                            <ul class="sub-list">
                                <?php $__currentLoopData = CategoryView::type('product'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="/product/<?php echo e($value->guid); ?>"><?php echo e($value->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </ul>
                            <h3><?php echo trans('header.solution'); ?></h3>
                            <?php if(App::getLocale() == 'zh-TW'): ?>
                                <ul class="sub-list">
                                    <li><a href="/solution-education">教育校園</a></li>
                                    <li><a href="/solution-government">政府機關</a></li>
                                    <li><a href="/solution-enterprise">企業製造業</a></li>
                                    <li><a href="/solution-ap">UAC無線網路整合</a></li>
                                </ul>
                            <?php else: ?>
                                <ul class="sub-list">
                                    <li><a href="/solution-education">Education</a></li>
                                    <li><a href="/solution-government">Government</a></li>
                                    <li><a href="/solution-enterprise">Enterprise</a></li>
                                    <li><a href="/solution-ap">UAC</a></li>
                                </ul>
                            <?php endif; ?>

                        </div>
                        <div class="col-md-5 footer-info">
                            <ul class="main-list">
                                <li><a href="/news"><?php echo trans('header.news'); ?></a></li>
                                <li><a href="/partners"><?php echo trans('header.partner'); ?></a></li>
                                <li><a href="/repair"><?php echo trans('header.support'); ?></a></li>
                                <li><a href="/about"><?php echo trans('header.about'); ?></a></li>
                                <li><a href="/success"><?php echo trans('header.success_case'); ?></a></li>
                                <li><a href="/bidding"><?php echo trans('header.bidding_project'); ?></a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 footer-info">
                            <ul class="lang-list">
                                
                            </ul>
                            <div class="social-section">
                                <h5>SALES TEAM</h5>
                                <p><?php echo e(SiteMetaView::other()->phone); ?></p>
                                <a class="mail_btn" href="mailto:<?php echo e(SiteMetaView::other()->email); ?>">SEND US YOUR REQUEST</a>
                                <br>
                                <a>FOLLOW US</a>
                                <a href="<?php echo e(SiteMetaView::other()->facebook); ?>">
                                    <i class="fa fa-facebook-official" aria-hidden="true"></i>
                                </a>
                                <a href="<?php echo e(SiteMetaView::other()->youtube); ?>">
                                    <i class="fa fa-youtube" aria-hidden="true"></i>
                                </a>
                                <a href="<?php echo e(SiteMetaView::other()->instagram); ?>">
                                    <i class="fa fa-instagram" aria-hidden="true"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 copyright">
                    <?php echo trans('string.copyright'); ?>

                </div>
            </div>
        </div>



        <script src="/js/frontend-all.js" charset="utf-8"></script>

        <?php echo $__env->yieldContent('custom-js-script'); ?>

        <?php if(config('app.env') == 'local'): ?>
            <script src="http://localhost:35729/livereload.js"></script>
        <?php endif; ?>
    </body>
</html>
