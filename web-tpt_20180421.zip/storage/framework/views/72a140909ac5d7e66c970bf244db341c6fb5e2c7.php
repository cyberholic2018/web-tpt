<!doctype html>
<html class="no-js" lang="">
  <head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e('柏策科技 NetONE Tech'); ?></title>

    <link rel="shortcut icon" href="<?php echo e('http://demo5.egith.net/photos/2/netone_icon-01-01.png'); ?>">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="/styles/vendor.css">

    <link rel="stylesheet" href="/styles/main.css">

    <link rel="stylesheet" href="/css/frontend.css">

    <link rel="stylesheet" type="text/css" href="/js/plugins/slider/engine1/style.css" />

    <link rel="stylesheet" href="/css/toastr.min.css">

    <script src="/scripts/vendor/modernizr.js"></script>

    <?php echo $__env->yieldContent('custom-style'); ?>
  </head>
  <body>
    <!--[if IE]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <?php echo $__env->yieldContent('custom-header'); ?>
    <div id="frontend-loading-bar">
        <img src="/img/icon/loading-bar.svg" alt="">
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="netone-header col-md-8 col-md-offset-2">
                <div class="row">
                    <div class="col-md-3 index-header">
                        <div class="page-header">
                            <h1>
                                <a href="<?php echo e(url('/')); ?>">
                                    <img class="index-logo" src="/images/netone-logo.png" title="<?php echo e('柏策科技 NetONE Tech'); ?>" alt="<?php echo e('柏策科技 NetONE Tech'); ?>" width="200">
                                </a>
                            </h1>
                        </div>
                        <div class="nav-toggle">
                            <img width="30" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0nMjAwJyBoZWlnaHQ9JzIwMCcgZmlsbD0iIzdhMTEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iLTUxMiA3NDEgOTcuOCA1My42IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IC01MTIgNzQxIDk3LjggNTMuNjsiIHhtbDpzcGFjZT0icHJlc2VydmUiPjxwYXRoIGQ9Ik0tNDE2LDc0MWgtOTQuMmMtMSwwLTEuOCwwLjgtMS44LDEuOHMwLjgsMS44LDEuOCwxLjhoOTQuMmMxLDAsMS44LTAuOCwxLjgtMS44Uy00MTUsNzQxLTQxNiw3NDF6Ii8+PHBhdGggZD0iTS00MTYsNzY2aC05NC4yYy0xLDAtMS44LDAuOC0xLjgsMS44czAuOCwxLjgsMS44LDEuOGg5NC4yYzEsMCwxLjgtMC44LDEuOC0xLjhTLTQxNSw3NjYtNDE2LDc2NnoiLz48cGF0aCBkPSJNLTQxNiw3OTFoLTk0LjJjLTEsMC0xLjgsMC44LTEuOCwxLjhzMC44LDEuOCwxLjgsMS44aDk0LjJjMSwwLDEuOC0wLjgsMS44LTEuOFMtNDE1LDc5MS00MTYsNzkxeiIvPjwvc3ZnPg==" alt="">
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="social-area">
                                    <div class="social-icon-area pull-right">
                                        <a target="_blank" href="https://www.facebook.com/netonetech/">
                                            <img src="/images/facebook_icon-01.svg" width="15" alt="">
                                        </a>
                                        <a href="#" id="phone-area">
                                            <img src="/images/phone_icon-01.svg" width="15" alt="">
                                            <div class="hover-info">
                                                02-7702-7000
                                            </div>
                                        </a>
                                        <a href="<?php echo e(url('/contact')); ?>">
                                            <img src="/images/mail_icon-01.svg" width="15" alt="">
                                        </a>
                                        <a href="<?php echo e(url('/contact')); ?>">
                                            <img src="/images/location_icon-01.svg" width="15" alt="">
                                        </a>
                                    </div>
                                    <div class="social-support-area pull-right">
                                        <span>Need more support?</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <nav class="navbar navbar-default netone-nav" role="navigation">
                                    
                                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                        <ul class="nav navbar-nav pull-right">
                                            <li>
                                                <a href="<?php echo e(url('/about')); ?>">關於柏策<br><span class="nav-eng-info">About us</span></a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(url('/brandAgent')); ?>">品牌代理<br><span class="nav-eng-info">Brand agent</span></a>
                                            </li>
                                            <li class="dropdown">
                                                <a href="<?php echo e(url('/solution')); ?>">解決方案<br><span class="nav-eng-info">Solution</span></a>
                                            </li>
                                            <li class="dropdown">
                                                <a href="<?php echo e(url('/news')); ?>">最新消息<br><span class="nav-eng-info">News</span></a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(url('/support')); ?>">支援專區<br><span class="nav-eng-info">Support</span></a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(url('/contact')); ?>">聯絡我們<br><span class="nav-eng-info">Contact us</span></a>
                                            </li>
                                        </ul>
                                        
                                    </div>

                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div style="width: 50%; margin: 100px auto">
                    <img src="/photos/shares/404page.png" width="100%" alt="">
                </div>


            </div>
        </div>
        <div class="row">
            <div class="col-md-12" style="padding: 0">
                <div class="row index-section footer"  style="margin-top: 0">
                    <div class="col-md-6 col-md-offset-1" >
                        <img class="footer-logo" height="100" src="/images/netone_logo_black-01.png" alt="">
                    </div>
                    <div class="col-md-5">
                        <p><?php echo e('柏策科技 NetONE Tech'); ?></p>
                        <p>NetONE Technology Co., Ltd.</p>
                        <p>10476 台北市中山區民權東路三段35號11樓</p>
                        <p>TEL: 02-7702-7000</p>
                        <p>FAX: 02-7702-7099</p>
                    </div>
                </div>
            </div>
            <div class="col-md-12 copyright-sec">
                <p>&copy; 2017 NetONE Technology Co., Ltd. All rights reserved.</p>
            </div>
        </div>
    </div>


    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
    <script>
      (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
      function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
      e=o.createElement(i);r=o.getElementsByTagName(i)[0];
      e.src='https://www.google-analytics.com/analytics.js';
      r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
      ga('create','UA-XXXXX-X');ga('send','pageview');
    </script>

    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            ]); ?>
    </script>

    <script src="/scripts/vendor.js"></script>

    <script src="<?php echo e(asset('js/all.js')); ?>"></script>

    <script src="/scripts/plugins.js"></script>

    <script src="/js/main.js"></script>

    <script src='https://www.google.com/recaptcha/api.js'></script>

    <?php echo $__env->yieldContent('custom-js-script'); ?>

    <?php if(config('app.env') == 'local'): ?>
        <script src="http://localhost:35729/livereload.js"></script>
    <?php endif; ?>
  </body>
</html>
