<?php $__env->startSection('custom-js-script'); ?>
<script type="text/javascript" src="js/plugins/slider/engine1/wowslider.js"></script>
<script type="text/javascript" src="js/plugins/slider/engine1/script.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">

            <div id="wowslider-container1">
            	<div class="ws_images">
                    <ul>
                        <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><img src="<?php echo e($item->url); ?>" alt="<?php echo e($item->title); ?>" title="<?php echo e($item->title); ?>"/></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            	    </ul>
                </div>
            	<div class="ws_bullets">
                    <div>
                        <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="#" title="<?php echo e($item->title); ?>"><span><img height="48" src="<?php echo e($item->url); ?>" alt="<?php echo e($item->title); ?>"/>1</span></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            	<div class="ws_shadow"></div>
        	</div>
        </div>
    </div>
    

    <?php $__currentLoopData = $topCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="row index-section slick-section">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($prod->category == $sub->guid): ?>
                                <?php if($sub->parentId == $top->guid): ?>
                                    <div class="col-md-3">
                                        <a href="/solutionDetail/<?php echo e($prod->guid); ?>" style="text-decoration: none;">
                                            <div class="thumbnail">
                                                <img alt="Bootstrap Thumbnail First" src="<?php echo e($prod->featureImage); ?>" />
                                                <div class="caption">
                                                    <h3>
                                                        <?php echo e($prod->title); ?>

                                                    </h3>
                                                    
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>