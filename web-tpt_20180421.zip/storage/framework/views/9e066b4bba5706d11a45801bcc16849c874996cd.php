<?php $__env->startSection('content'); ?>
    <div class="row" id="netone-solution">
        <div class="col-md-8 col-md-offset-2 about-content">
            <h3>解決方案</h3>
            <hr>
            <div class="col-md-3 product-category-tree">
                
                <h4>產品介紹</h4>
                <hr>
                <ul>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->parentId == null): ?>
                            <?php if($parentCategory == $item->guid): ?>
                                <li class="active"><a href="/solution/?type=<?php echo e($item->guid); ?>"><?php echo e($item->title); ?></a>
                                    <ul>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($subItem->parentId == $item->guid): ?>
                                                <li><a href="/solution/?type=<?php echo e($subItem->guid); ?>"><?php echo e($subItem->title); ?></a></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php else: ?>
                                <li class="active"><a href="/solution/?type=<?php echo e($item->guid); ?>"><?php echo e($item->title); ?></a>
                                    <ul>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($subItem->parentId == $item->guid): ?>
                                                <li><a href="/solution/?type=<?php echo e($subItem->guid); ?>"><?php echo e($subItem->title); ?></a></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <img src="<?php echo e($featureImage); ?>" alt="" width="100%">
                    </div>
                    <div class="col-md-12">
                        <h2><?php echo e($productTitle); ?></h2>
                        <hr>
                        <div class="tabbable" id="tabs-848731">
            				<ul class="nav nav-tabs product-tabs">
                                <?php $__currentLoopData = $productContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(array_search($item, $productContent) == 0): ?>
                                        <li class="active">
                                            <a href="#<?php echo e($item->tabId); ?>" data-toggle="tab"><?php echo e($item->title); ?></a>
                                        </li>
                                    <?php else: ?>
                                        <li>
                    						<a href="#<?php echo e($item->tabId); ?>" data-toggle="tab"><?php echo e($item->title); ?></a>
                    					</li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            				</ul>
            				<div class="tab-content">
                                <?php $__currentLoopData = $productContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(array_search($item, $productContent) == 0): ?>
                                        <div class="tab-pane active" id="<?php echo e($item->tabId); ?>">
                    						<?php echo $item->content; ?>

                    					</div>
                                    <?php else: ?>
                                        <div class="tab-pane" id="<?php echo e($item->tabId); ?>">
                    						<?php echo $item->content; ?>

                    					</div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            				</div>
            			</div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>