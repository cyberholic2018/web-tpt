<?php $__env->startSection('sub-content'); ?>
    <?php echo $pageContent->content; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.contact.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>