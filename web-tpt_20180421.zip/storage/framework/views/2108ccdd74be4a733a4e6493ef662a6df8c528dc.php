<?php $__env->startSection('custom-js-script'); ?>
	<?php echo $__env->yieldContent('custom-js-script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-style-section'); ?>
	<?php echo $__env->yieldContent('custom-style-section'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-panel-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style media="screen">

</style>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-2" id="admin-sidebar">
	        <admin-sidebar></admin-sidebar>
	    </div>
		<div class="col-md-10">
			<div class="panel panel-default">
				<div class="panel-heading"><?php echo e($panelTitle); ?></div>
				<div class="panel-body">
					<?php echo $__env->yieldContent('panel-content'); ?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php echo $__env->yieldContent('script'); ?>
<?php echo $__env->yieldContent('style'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>