<?php $__env->startSection('custom-style'); ?>
    <style media="screen">
        .page-contant-header {
            background-image: url('<?php echo $pageContent->featureImage; ?>');
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="page-contant-header about">
                <h2><?php echo e($pageContent->title); ?></h2>
            </div>
            <div class="page-thumbnail">
                <span class="glyphicon glyphicon-home" aria-hidden="true"></span>
                <span>></span>
                <span>Privacy, Terms & Conditions</span>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <ul class="page-side-menu">
                <li><a class="<?php echo e($active01); ?>" href="/legalthings">Privacy, Terms & Conditions</a></li>
                <li><a class="<?php echo e($active02); ?>" href="/legalthings/privacy">Privacy</a></li>
                <li><a class="<?php echo e($active03); ?>" href="/legalthings/termsofuse">Terms of Use</a></li>
                <li><a class="<?php echo e($active04); ?>" href="/legalthings/conditionsofsale">Conditions of Sale</a></li>
            </ul>
        </div>
        <div class="col-md-9 sub-page-content">
            <?php echo $__env->yieldContent('sub-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>