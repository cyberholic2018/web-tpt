<?php $__env->startSection('custom-js-script'); ?>
<script type="text/javascript" src="js/plugins/slider/engine1/wowslider.js"></script>
<script type="text/javascript" src="js/plugins/slider/engine1/script.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">

            <div id="wowslider-container1">
            	<div class="ws_images">
                    <ul>
                        <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><img src="<?php echo e($item->url); ?>" alt="<?php echo e($item->title); ?>" title="<?php echo e($item->title); ?>"/></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            	    </ul>
                </div>
            	<div class="ws_bullets">
                    <div>
                        <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="#" title="<?php echo e($item->title); ?>"><span><img height="48" src="<?php echo e($item->url); ?>" alt="<?php echo e($item->title); ?>"/>1</span></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            	<div class="ws_shadow"></div>
        	</div>
        </div>
    </div>

    


    <div class="row">
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="row index-section">
                    <div class="col-md-12" style="text-align: center">
                        <img alt="Bootstrap Thumbnail First" width="60%" src="<?php echo e($item->parentId); ?>">
                        <div>
                            <h4>
                                <?php echo e($item->title); ?>

                            </h4>
                            <div class="description">
                                <?php echo $item->description; ?>

                            </div>
                        </div>
                        <a href="/product/<?php echo e($item->guid); ?>" class="read-more-btn">Read More..</a>
                        
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>