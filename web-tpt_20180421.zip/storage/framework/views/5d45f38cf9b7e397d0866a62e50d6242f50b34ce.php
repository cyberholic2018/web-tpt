<?php $__env->startSection('sub-script'); ?>
    <script src="<?php echo e(asset('js/netone-news.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-content'); ?>
    <div class="row" id="netone-news">
        <div class="col-md-12">
            
            
            <netone-news></netone-news>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.news.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>