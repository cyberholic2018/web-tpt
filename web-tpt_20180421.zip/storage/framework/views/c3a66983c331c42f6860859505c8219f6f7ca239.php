<?php $__env->startSection('sub-content'); ?>
    <h3><?php echo e($currentProduct->title); ?></h3>
    <img src="<?php echo e($currentProduct->featureImage); ?>" alt="">
    <h4>Detail</h4>
    <hr>
    <?php echo $currentProduct->shortDescription; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.product.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>