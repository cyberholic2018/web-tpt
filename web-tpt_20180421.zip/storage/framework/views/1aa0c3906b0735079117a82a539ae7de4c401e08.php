<?php $__env->startSection('custom-header'); ?>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/zh_TW/sdk.js#xfbml=1&version=v2.10&appId=124798941401730";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-style'); ?>
<style>
#facebook-share, #line-share {
cursor: pointer;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js-script'); ?>
<script>
jQuery('#line-share').on('click', function() {
  window.open("http://line.me/R/msg/text/?" + document.title + '%0D%0A' + window.location.href);
});

jQuery('#facebook-share').on('click', function() {
  window.open("https://www.facebook.com/sharer/sharer.php?u=" + window.location.href + '&src=sdkpreparse');
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row" id="netone-news">
        <div class="col-md-8 col-md-offset-2 about-content">
            <h2><?php echo e($post->title); ?></h2>
            <h4><?php echo date('Y-m-d', strtotime($post->created_at)); ?></h4>
            <table style="width: 80px;">
                <tr>
                    <td width="50%" align="left" style="border-bottom: none;"><img id="facebook-share" class="alignleft" src="http://maxim-meterials.com.tw/wp-content/uploads/2017/08/facebook-icon.svg" alt="" width="80%" /></td>
                    <td width="50%" align="left" style="border-bottom: none;"><img id="line-share" class="aligncenter" src="http://maxim-meterials.com.tw/wp-content/uploads/2017/08/line-icon.svg" alt="" width="80%" /></td>
                </tr>
            </table>
            <hr>
            <img src="<?php echo e($post->featureImage); ?>" width="100%">
            <hr>
            <?php echo $post->content; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>