<?php $__env->startSection('custom-js-script'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row" id="netone-solution">
        <div class="col-md-8 col-md-offset-2 about-content">
            <h3>解決方案</h3>
            <hr>
            
            <div class="col-md-3 product-category-tree">
                
                <h4>產品介紹</h4>
                <hr>
                <ul>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->parentId == null): ?>
                            
                            <li class="active"><a href="#"><?php echo e($item->title); ?></a>
                                <ul>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($subItem->parentId == $item->guid): ?>
                                            <li><a href="/solution/<?php echo e($subItem->guid); ?>"><?php echo e($subItem->title); ?></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
            <div class="col-md-9">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row product-content-horizon">
                        <div class="col-md-4 product-feature-image">
                            <img src="<?php echo e($item->featureImage); ?>" alt="">
                        </div>
                        <div class="col-md-8 product-info">
                            <a class="product-title" href="/solutionDetail/<?php echo e($item->guid); ?>">
                                <h4><?php echo e($item->title); ?></h4>
                            </a>
                            <hr>
                            <div class="product-content">
                                <?php echo $item->shortDescription; ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>