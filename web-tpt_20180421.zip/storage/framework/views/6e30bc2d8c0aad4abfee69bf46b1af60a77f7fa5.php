<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="<?php echo e(SiteMetaView::keyword()); ?>">
        <meta name="description" content="<?php echo e(SiteMetaView::description()); ?>">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <?php echo $__env->yieldContent('custom-meta'); ?>

        
        <title><?php echo e(SiteMetaView::title()); ?></title>

        <link rel="shortcut icon" href="<?php echo e(SiteMetaView::shortcut()); ?>">

        <!-- Fonts -->
        <link href="<?php echo e(asset('css/frontend.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="/js/plugins/AOS/aos.css">
        <link rel="stylesheet" href="/css/animate.css">

        <!-- Styles -->
        <style>
        .paytest {
            display: block;
            font-size: 50pt;
        }
        </style>

        
        <?php echo $__env->yieldContent('custom-style'); ?>

        <!-- Facebook Pixel Code -->
        <!-- End Facebook Pixel Code -->

    </head>
    <body>
        <div class="loading-bar">
            <img src="/img/icon/default-loading.svg">
        </div>
        <?php if (! (Auth::guest())): ?>
            <?php if(Auth::user()->role == 'ADMIN'): ?>
                
            <?php endif; ?>
        <?php endif; ?>

        
        <button id="side-bar-btn">
            <span></span>
            <span></span>
            <span></span>
        </button>

        <div class="menu-panel">
            <div class="gray-layer">

            </div>
            <div class="menu-section hide">
                <div class="site-logo">
                    <a href="/"><img src="/img/tpt-logo.png" alt="<?php echo e(SiteMetaView::title()); ?>" title="<?php echo e(SiteMetaView::title()); ?>"></a>
                </div>


                <ul>
                    <li>
                        <a href="<?php echo e(url('/about')); ?>">
                            <span>關於帕太</span>
                            <br>
                            About POWERTECH
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/news')); ?>">
                            <span>最新消息</span>
                            <br>
                            News & Infomation
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/product')); ?>">
                            <span>產品介紹</span>
                            <br>
                            Product Infomation
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/partner')); ?>">
                            <span>合作夥伴</span>
                            <br>
                            Our Partners
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/contact')); ?>">
                            <span>聯絡我們</span>
                            <br>
                            Contact Us
                        </a>
                    </li>
                </ul>
                <br><br><br>

                
            </div>
        </div>

        
        <?php echo $__env->yieldContent('content'); ?>

        

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/frontend.js')); ?>"></script>

        <script src="<?php echo e(asset('js/CH-lib.js')); ?>"></script>

        

        <script src="<?php echo e(asset('js/plugins/AOS/aos.js')); ?>" charset="utf-8"></script>

        <script type="text/javascript">
            AOS.init();

            $(document).ready(function() {
                $('.loading-bar').fadeOut('fast');
            });
        </script>

        
        <?php echo $__env->yieldContent('custom-script'); ?>

        <?php if(config('app.env') == 'local'): ?>
            <script src="http://localhost:35729/livereload.js"></script>
        <?php endif; ?>

        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-110216165-1"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', 'UA-110216165-1');
        </script>


    </body>
</html>
