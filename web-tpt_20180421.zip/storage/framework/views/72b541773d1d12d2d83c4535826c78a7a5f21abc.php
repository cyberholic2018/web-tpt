<?php $__env->startSection('custom-js-script'); ?>
    <script src="<?php echo e(asset('js/netone-news.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row" id="netone-news">
        <div class="col-md-8 col-md-offset-2 about-content">
            <h3>最新消息</h3>
            <hr>
            <netone-news></netone-news>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>