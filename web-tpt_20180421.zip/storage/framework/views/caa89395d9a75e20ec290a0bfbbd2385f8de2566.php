<?php $__env->startSection('custom-style'); ?>
    <style media="screen">
        .page-content-header {
            background-image: url('<?php echo $pageContent->featureImage; ?>');
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 page-content">
            <div class="page-content-header">
                <h2><?php echo e($pageContent->title); ?></h2>
            </div>
        </div>
    </div>
    <div class="row">
        
        <div class="col-md-12 sub-page-content">
            <?php echo $__env->yieldContent('sub-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>