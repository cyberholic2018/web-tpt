<?php $__env->startSection('custom-js-script'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel-content'); ?>
    <div class="row ch-post-form">
        <div class="col-md-6">
            <?php if($mode == 'add'): ?>
                <form action="/partner/add" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="guid" value="<?php echo e(PublicServiceProvider::generateGuid()); ?>">
                    <div class="form-group">
                        <label for="name">合作夥伴名稱</label>
                        <input type="text" name="name" id="name" class="form-control" value="" required>
                    </div>
                    <div class="form-group">
                        <label for="addressString">地址</label>
                        <input type="text" name="addressString" id="addressString" class="form-control" value="" required>
                    </div>
                    <div class="form-group">
                        <label for="locale">選擇語系</label>
                        <select class="form-control" id="locale" name="locale">
                            <?php $__currentLoopData = Config::get('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="partnerType">選擇合作夥伴類別</label>
                        <select class="form-control" id="partnerType" name="partnerType" required>
                            <?php $__currentLoopData = CategoryView::type2('partnerType'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->guid); ?>"><?php echo e($value->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="partnerLocation">選擇合作夥伴區域</label>
                        <select class="form-control" id="partnerLocation" name="partnerLocation" required>
                            <?php $__currentLoopData = CategoryView::type2('partnerLocation'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->guid); ?>"><?php echo e($value->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="link">網站連結</label>
                        <input type="text" name="link" id="link" class="form-control" value="" required>
                    </div>
                    <div class="form-group">
                        <label for="longitude">經度</label>
                        <input type="text" name="longitude" id="longitude" class="form-control" value="" required>
                    </div>
                    <div class="form-group">
                        <label for="latitude">緯度</label>
                        <input type="text" name="latitude" id="latitude" class="form-control" value="" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg" name="button">新增合作夥伴</button>
                </form>
            <?php else: ?>
                <form action="/partner/edit/<?php echo e($partner->guid); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name">合作夥伴名稱</label>
                        <input type="text" name="name" id="name" class="form-control" value="<?php echo e($partner->name); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="addressString">地址</label>
                        <input type="text" name="addressString" id="addressString" class="form-control" value="<?php echo e($partner->addressString); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="locale">選擇語系</label>
                        <select class="form-control" id="locale" name="locale">
                            <?php $__currentLoopData = Config::get('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($partner->locale == $key): ?>
                                    <option value="<?php echo e($key); ?>" selected><?php echo e($value); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="partnerType">選擇合作夥伴類別</label>
                        <select class="form-control" id="partnerType" name="partnerType" required>
                            <?php $__currentLoopData = CategoryView::type2('partnerType'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($partner->partnerType == $value->guid): ?>
                                    <option value="<?php echo e($value->guid); ?>" selected><?php echo e($value->title); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($value->guid); ?>"><?php echo e($value->title); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="partnerLocation">選擇合作夥伴區域</label>
                        <select class="form-control" id="partnerLocation" name="partnerLocation" required>
                            <?php $__currentLoopData = CategoryView::type2('partnerLocation'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($partner->partnerLocation == $value->guid): ?>
                                    <option value="<?php echo e($value->guid); ?>" selected><?php echo e($value->title); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($value->guid); ?>"><?php echo e($value->title); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="link">網站連結</label>
                        <input type="text" name="link" id="link" class="form-control" value="<?php echo e($partner->link); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="longitude">經度</label>
                        <input type="text" name="longitude" id="longitude" class="form-control" value="<?php echo e($partner->longitude); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="latitude">緯度</label>
                        <input type="text" name="latitude" id="latitude" class="form-control" value="<?php echo e($partner->latitude); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg" name="button">更新合作夥伴</button>
                </form>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>