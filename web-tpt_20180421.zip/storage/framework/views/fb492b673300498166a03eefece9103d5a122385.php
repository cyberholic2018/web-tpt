<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <div class="row product-section">
            <div class="col-md-9">
                <br><br>
                <?php echo CategoryView::get($guid)->description; ?>

            </div>
            <div class="col-md-3 right-side-bar">
                <h3><?php echo trans('string.how_to_buy'); ?></h3>
                <p><?php echo trans('string.you_can_call'); ?> :</p>
                <p>(02)2797-7568</p>
                <p><?php echo trans('string.commissioner_contact'); ?></p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row product-section" style="margin-bottom: 50px">
                    <?php $__currentLoopData = ProductView::getByCategory($guid); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 product-box">
                            <h4><?php echo e($item->title); ?></h4>
                            <img class="product-img" width="100%" src="<?php echo e($item->featureImage); ?>" alt="">
                            <?php echo $item->shortDescription; ?>


                            <a href="/product/detail/<?php echo e($item->guid); ?>"><?php echo trans('string.learn_more'); ?></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <br><br>
                <?php echo e(ProductView::getByCategory($guid)); ?>

                <br><br>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.product.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>