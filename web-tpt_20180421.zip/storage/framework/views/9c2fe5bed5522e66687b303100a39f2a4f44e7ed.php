<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2 about-content">
            <h3>支援專區</h3>
            <hr>
            <h4>驅動程式</h4>
            <table class="table support-table">
                <thead>
                    <tr>
                        <th align="center" width="50">
                            編號
                        </th>
                        <th>
                            名稱
                        </th>
                        <th>
                            適用環境
                        </th>
                        <th align="center" width="75">
                            檔案大小
                        </th>
                        <th align="center" width="75">
                            下載連結
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i=0; $i < count($driver); $i++): ?>
                        <tr>
                            <td align="center">#<?php echo e($i + 1); ?></td>
                            <td><?php echo e($driver[$i]->fileName); ?></td>
                            <td><?php echo e($driver[$i]->osCondition); ?></td>
                            <td align="center">
                                <?php if($driver[$i]->fileSize < 1024): ?>
                                    <?php echo e($driver[$i]->fileSize); ?> bytes
                                <?php elseif(($driver[$i]->fileSize >= 1024) && ($driver[$i]->fileSize < 1048576)): ?>
                                    <?php echo e(round($driver[$i]->fileSize / 1024, 2)); ?> KB
                                <?php elseif($driver[$i]->fileSize >= 1048576): ?>
                                    <?php echo e(round($driver[$i]->fileSize / 1048576, 2)); ?> MB
                                <?php endif; ?>
                            </td>
                            <td align="center"><a href="<?php echo e($driver[$i]->downloadLink); ?>"><span class="glyphicon glyphicon-download-alt"></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td colspan="4">
                                說明：<?php echo e($driver[$i]->description); ?>

                            </td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
            <hr>
            <h4>技術文件</h4>
            <table class="table support-table">
                <thead>
                    <tr>
                        <th>
                            名稱
                        </th>
                        <th align="center" width="75">
                            檔案大小
                        </th>
                        <th align="center" width="75">
                            下載連結
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $support; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->type == '技術文件'): ?>
                            <tr>
                                <td><?php echo e($item->fileName); ?></td>
                                <td align="center">
                                    <?php if($item->fileSize < 1024): ?>
                                        <?php echo e($item->fileSize); ?> bytes
                                    <?php elseif(($item->fileSize >= 1024) && ($item->fileSize < 1048576)): ?>
                                        <?php echo e(round($item->fileSize / 1024, 2)); ?> KB
                                    <?php elseif($item->fileSize >= 1048576): ?>
                                        <?php echo e(round($item->fileSize / 1048576, 2)); ?> MB
                                    <?php endif; ?>
                                </td>
                                <td align="center"><a href="<?php echo e($item->downloadLink); ?>"><span class="glyphicon glyphicon-download-alt"></span></a></td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>