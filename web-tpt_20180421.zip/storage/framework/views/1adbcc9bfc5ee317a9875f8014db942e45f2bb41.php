<!doctype html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e($title); ?></title>

        <link rel="shortcut icon" href="<?php echo e($shortcut); ?>">

        <link rel="stylesheet" href="/css/frontend.css">

        <script src="/js/vendor/modernizr.js"></script>

        <?php echo $__env->yieldContent('custom-style'); ?>

    </head>
    <body>
        <div class="loading-bar">
            <img src="/img/icon/loading-bar.svg" alt="">
        </div>

        <?php echo $__env->yieldContent('custom-header'); ?>

        <div class="container">
            <div class="row social-header">
                <div class="col-md-12 social-content">
                    <a href="#">
                        <img width="15" src="/images/location_icon-01-01.png" alt="">
                    </a>
                    <a href="#">
                        <img width="15" src="/images/search_icon-01-01-01.png" alt="">
                    </a>
                    <a href="#">
                        <img width="15" src="/images/mail_icon-01-01-01.png" alt="">
                    </a>
                    <a href="#">
                        <img width="15" src="/images/call_icon-01-01.png" alt="">
                    </a>
                    <a href="#">
                        <img width="15" src="/images/mylove_icon-01-01.png" alt="">
                    </a>
                    <a href="#">
                        <img width="15" src="/images/fb_icon-01-01-01.png" alt="">
                    </a>
                    <a href="#" class="sitemap">
                        Check here to find the sitemap
                    </a>
                    <a href="#">
                        <img width="15" src="/images/info_icon-01-01.png" alt="">
                    </a>
                </div>
            </div>
            <div class="row site-header">
                <div id="logo-section" class="col-md-2">
                    <div class="site-logo">
                        <img src="/images/index_logo-en.png" alt="">
                    </div>
                    <div id="nav-btn" class="">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
                <div id="nav-section" class="col-md-10">
                    <nav class="site-nav pull-right">
                        <img class="nav-logo" src="/images/index_logo-en.png" alt="">
                        <ul>
                            <li><a href="#">產品資訊<br><span>Products</span></a></li>
                            <li><a href="#">解決方案<br><span>Solutions</span></a></li>
                            <li><a href="#">合作夥伴<br><span>Partner</span></a></li>
                            <li><a href="#">服務支援<br><span>Support</span></a></li>
                            <li><a href="#">關於崴遠<br><span>About Us</span></a></li>
                            <li><a href="#">最新消息<br><span>News</span></a></li>
                            <li><a href="#">成功案例<br><span>Success Case</span></a></li>
                            <li><a href="#">工業局軟體標<br><span>Bidding Project</span></a></li>
                        </ul>
                        <div class="social-section">
                            <a href="#">
                                <img width="30" src="/images/location_icon-01-01_b.png" alt="">
                            </a>
                            <a href="#">
                                <img width="30" src="/images/search_icon-01-01-01_b.png" alt="">
                            </a>
                            <a href="#">
                                <img width="30" src="/images/mail_icon-01-01-01_b.png" alt="">
                            </a>
                            <a href="#">
                                <img width="30" src="/images/call_icon-01-01_b.png" alt="">
                            </a>
                            <a href="#">
                                <img width="30" src="/images/mylove_icon-01-01_b.png" alt="">
                            </a>
                            <a href="#">
                                <img width="30" src="/images/fb_icon-01-01-01_b.png" alt="">
                            </a>
                        </div>
                    </nav>
                </div>
            </div>


        </div>

        <div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <div class="container-fluid footer-section">
            <div class="row">
                <div class="col-md-3 footer-info">
                    <h3>產品資訊 Product</h3>
                    <ul class="sub-list">
                        <li>UAC - 應用流量控制器</li>
                        <li>UWAN - 網路線路附載平衡器</li>
                        <li>UAC - 虛擬化協同實驗室</li>
                    </ul>
                    <h3>解決方案 Solutions</h3>
                    <ul class="sub-list">
                        <li>教育校園</li>
                        <li>政府機關</li>
                        <li>企業製造業</li>
                        <li>UAC無線網路整合</li>
                    </ul>
                </div>
                <div class="col-md-4 footer-info">
                    <ul class="main-list">
                        <li>最新消息 News</li>
                        <li>合作夥伴 Partner Network</li>
                        <li>服務支援 Service Support</li>
                        <li>關於崴遠 About Us</li>
                        <li>成功案例 Success Case</li>
                        <li>工業局軟體標 Bidding Project</li>
                    </ul>
                </div>
                <div class="col-md-2 footer-info">

                </div>
                <div class="col-md-3 footer-info">
                    <div class="social-section">
                        <a href="#">
                            <img width="20" src="/images/location_icon-01-01.png" alt="">
                        </a>
                        <a href="#">
                            <img width="20" src="/images/search_icon-01-01-01.png" alt="">
                        </a>
                        <a href="#">
                            <img width="20" src="/images/mail_icon-01-01-01.png" alt="">
                        </a>
                        <a href="#">
                            <img width="20" src="/images/call_icon-01-01.png" alt="">
                        </a>
                        <a href="#">
                            <img width="20" src="/images/mylove_icon-01-01.png" alt="">
                        </a>
                        <a href="#">
                            <img width="20" src="/images/fb_icon-01-01-01.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 copyright">
                    Copyright &copy; <?php echo e(date("Y")); ?> 崴遠科技股份有限公司 版權所有 | (02)2797-7568 | 
                </div>
            </div>
        </div>



        <script src="/js/frontend-all.js" charset="utf-8"></script>

        <?php echo $__env->yieldContent('custom-js-script'); ?>

        <?php if(config('app.env') == 'local'): ?>
            <script src="http://localhost:35729/livereload.js"></script>
        <?php endif; ?>
    </body>
</html>
