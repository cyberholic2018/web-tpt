<?php $__env->startSection('content'); ?>
    <div class="row" id="netone-news">
        <div class="col-md-8 col-md-offset-2 about-content">
            <h3>最新消息</h3>
            <hr>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>