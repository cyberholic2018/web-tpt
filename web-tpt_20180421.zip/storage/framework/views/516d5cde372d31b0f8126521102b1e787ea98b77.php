<!doctype html>
<html class="no-js" lang="">
  <head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>netone</title>

    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <!-- Place favicon.ico in the root directory -->

    <link rel="stylesheet" href="styles/vendor.css">

    <link rel="stylesheet" href="styles/main.css">

    <script src="scripts/vendor/modernizr.js"></script>
  </head>
  <body>
    <!--[if IE]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="row">
                    <div class="col-md-8 index-header">
                        <div class="page-header">
                            <h1>
                                <img class="index-logo" src="images/netone-logo.png" alt="柏策科技有限公司" width="200">
                            </h1>
                        </div>
                    </div>
                    <div class="col-md-4 index-header-search">
                        <table>
                            <tr>
                                <td colspan="2" align="right">
                                    <a class="social-icon" href="#"><img width="30" src="images/FB(RED).png" alt=""></a>
                                    <a class="social-icon" href="#"><img width="30" src="images/IG(RED).png" alt=""></a>
                                    <a class="social-icon" href="#"><img width="30" src="images/TW(RED).png" alt=""></a>
                                </td>
                            </tr>
                            <!-- <tr>
                                <td><input type="text" class="form-control" placeholder="輸入搜尋更多..."/></td>
                                <td width="20">
                                    <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
                                </td>
                            </tr> -->
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-default netone-nav" role="navigation">
                            <div class="navbar-header">
            					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            						 <span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
            					</button>
            				</div>
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav">
                                    <li>
                                        <a href="#">關於柏策</a>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">解決方案<strong class="caret"></strong></a>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a href="#">StormShield</a>
                                            </li>
                                            <li>
                                                <a href="#">QNO</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">最新消息<strong class="caret"></strong></a>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a href="#">2017年度</a>
                                            </li>
                                            <li>
                                                <a href="#">2016年度</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="#">支援專區</a>
                                    </li>
                                    <li>
                                        <a href="#">聯絡我們</a>
                                    </li>
                                    <li>
                                        <a href="#">訂閱電子報</a>
                                    </li>
                                </ul>


                                <ul class="nav navbar-nav navbar-right">

                                </ul>
                            </div>

                        </nav>
                        <div class="carousel slide" id="carousel-302841">
                            <ol class="carousel-indicators">
                                <li data-slide-to="0" data-target="#carousel-302841" class="active">
                                </li>
                                <li data-slide-to="1" data-target="#carousel-302841">
                                </li>
                                <li data-slide-to="2" data-target="#carousel-302841">
                                </li>
                                <li data-slide-to="3" data-target="#carousel-302841">
                                </li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="item active">
                                    <img alt="Carousel Bootstrap First" src="images/indexBg/01.jpg" />
                                </div>
                                <div class="item">
                                    <img alt="Carousel Bootstrap Second" src="images/indexBg/02.jpg" />
                                </div>
                                <div class="item">
                                    <img alt="Carousel Bootstrap Third" src="images/indexBg/03.jpg" />
                                </div>
                                <div class="item">
                                    <img alt="Carousel Bootstrap First" src="images/indexBg/04.jpg" />
                                </div>
                            </div> <a class="left carousel-control" href="#carousel-302841" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a> <a class="right carousel-control" href="#carousel-302841" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="row index-section">
                            <div class="col-md-12">
                                <h3 class="text-center">
                                    最佳VPN安全解決方案
                                </h3>
                                <div class="row">
                                    <div class="col-md-7">
                                        <img alt="Bootstrap Image Preview" src="images/71.jpg" class="img-responsive" />
                                    </div>
                                    <div class="col-md-5">
                                        <div class="main-product-info">
                                            <ol>
                                                <li>
                                                    <strong>獨立主機採硬體式架構</strong><br>使用嵌入式專屬作業系統
                                                </li>
                                                <li>
                                                    <strong>光世代、ADSL、FTTB專用</strong><br>適用所有ISP線路
                                                </li>
                                                <li>
                                                    <strong>SSL VPN通道數35條</strong>
                                                </li>
                                                <li>
                                                    <strong>IPSec VPN通道數100條</strong>
                                                </li>
                                                <li>
                                                    <strong>PPTP行動用戶數40個</strong>
                                                </li>
                                            </ol>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- slick section 1 -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="row index-section slick-section">
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/product/01.png" />
                                    <div class="caption">
                                        <h3>
                                            SN710
                                        </h3>
                                        <p>
                                            Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/product/02.png" />
                                    <div class="caption">
                                        <h3>
                                            SN710
                                        </h3>
                                        <p>
                                            Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/product/03.png" />
                                    <div class="caption">
                                        <h3>
                                            SN710
                                        </h3>
                                        <p>
                                            Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/product/04.png" />
                                    <div class="caption">
                                        <h3>
                                            SN710
                                        </h3>
                                        <p>
                                            Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- slick section 2 -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="row index-section slick-section">
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/product/01.jpg" />
                                    <div class="caption">
                                        <h3>
                                            FQR7203
                                        </h3>
                                        <p>
                                            Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/product/02.jpg" />
                                    <div class="caption">
                                        <h3>
                                            FQR7200
                                        </h3>
                                        <p>
                                            Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/product/03.jpg" />
                                    <div class="caption">
                                        <h3>
                                            FQR7109
                                        </h3>
                                        <p>
                                            Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/product/04.jpg" />
                                    <div class="caption">
                                        <h3>
                                            FQR7111
                                        </h3>
                                        <p>
                                            Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- slick section 3 -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-header">
            				<h3>
            					柏策合作夥伴
            				</h3>
            			</div>
                        <div class="row index-section slick-section-partner">
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/stormshield_logo.png" />
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/qno-slider-logo-min-1.png" />
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/1470144943-3387299407_l.jpg" />
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/CyberoamLogo.png" />
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="thumbnail">
                                    <img alt="Bootstrap Thumbnail First" src="images/c34555f5-1fef-4a66-a1c5-af55858144b5.png" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="row index-section footer" >
                            <div class="col-md-7">
                                <p>柏策科技有限公司</p>
                                <p>NetONE Technology Co., Ltd.</p>
                                <p>10476 台北市中山區民權東路三段35號11樓</p>
                                <p>TEL: 02-34567890</p>
                                <p>FAX: 02-09876543</p>
                                <img class="footer-logo" src="images/netone-logo-white.png" alt="">
                            </div>
                            <div class="col-md-5">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3614.1594550432787!2d121.54003061549417!3d25.06258408395907!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3442abe35a4dce25%3A0x531822931b4ca2cb!2zMTA0OTHlj7DljJfluILkuK3lsbHljYDmsJHmrIrmnbHot6_kuInmrrUzNeiZnw!5e0!3m2!1szh-TW!2stw!4v1504111756068" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
    <script>
      (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
      function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
      e=o.createElement(i);r=o.getElementsByTagName(i)[0];
      e.src='https://www.google-analytics.com/analytics.js';
      r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
      ga('create','UA-XXXXX-X');ga('send','pageview');
    </script>

    <script src="scripts/vendor.js"></script>

    <script src="scripts/plugins.js"></script>

    <script src="scripts/main.js"></script>
  </body>
</html>
