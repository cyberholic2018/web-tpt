<?php $__env->startSection('custom-js-script'); ?>
<script src="<?php echo e(asset('js/backend/product-category.js')); ?>" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel-content'); ?>
<div class="row ch-product-form" id="product-category">
    <div class="col-md-12">
        <product-category></product-category>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>