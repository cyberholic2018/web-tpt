<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="page-contant-header about">
                <h2><?php echo e($contentTitle); ?></h2>
            </div>
            <div class="page-thumbnail">
                <span class="glyphicon glyphicon-home" aria-hidden="true"></span>
                <span>></span>
                <span>Products</span>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <ul class="page-side-menu">
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->guid == $currentCategory): ?>
                        <li><a class="active" href="/product/<?php echo e($item->guid); ?>"><?php echo e($item->title); ?></a></li>
                    <?php else: ?>
                        <li><a class="" href="/product/<?php echo e($item->guid); ?>"><?php echo e($item->title); ?></a></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="col-md-9 sub-page-content">
            <?php echo $__env->yieldContent('sub-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>