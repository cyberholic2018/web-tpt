<?php $__env->startSection('custom-style'); ?>
    <style media="screen">
        .page-content-header {
            background-image: url('/images/sunrise-1756274_1920.jpg');
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js-script'); ?>
    <?php echo $__env->yieldContent('sub-js-script'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 page-content">
            <div class="page-content-header">
                <?php if($mode == 'category'): ?>
                    <h2><?php echo e(CategoryView::get($guid)->title); ?></h2>
                <?php else: ?>
                    <h2><?php echo e(ProductView::get($guid)->title); ?></h2>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">
        
        <div class="col-md-12 sub-page-content">
            <?php echo $__env->yieldContent('sub-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>