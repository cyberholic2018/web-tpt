<?php $__env->startSection('sub-js-script'); ?>
    <script type="text/javascript">
        $(function() {
            $('.product-image').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: false,
                // fade: true,
                asNavFor: '.product-thumb'
           });
           $('.product-thumb').slick({
               slidesToShow: 3,
               slidesToScroll: 1,
               asNavFor: '.product-image',
               dots: true,
               // centerMode: true,
               focusOnSelect: true
           });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <div class="row product-section">
            <div class="col-md-9 product-detail">
                <div class="product-gallary">
                    <div class="product-image">
                        <div>
                            <img src="<?php echo e(ProductView::get($guid)->featureImage); ?>" alt="">
                        </div>
                        <?php $__currentLoopData = json_decode(ProductView::get($guid)->album); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <img src="<?php echo e($item->imageUrl); ?>" alt="">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="product-thumb">
                        <div class="box">
                            <img src="<?php echo e(ProductView::get($guid)->featureImage); ?>" alt="">
                        </div>
                        <?php $__currentLoopData = json_decode(ProductView::get($guid)->album); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="box">
                                <img src="<?php echo e($item->imageUrl); ?>" alt="">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <br>
                <ul class="nav nav-tabs">
                    <?php $__currentLoopData = json_decode(ProductView::get($guid)->description); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key == 0): ?>
                            <li class="active"><a data-toggle="tab" href="#<?php echo e($item->tabId); ?>"><?php echo e($item->title); ?></a></li>
                        <?php else: ?>
                            <li><a data-toggle="tab" href="#<?php echo e($item->tabId); ?>"><?php echo e($item->title); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <div class="tab-content">
                    <?php $__currentLoopData = json_decode(ProductView::get($guid)->description); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key == 0): ?>
                            <div id="<?php echo e($item->tabId); ?>" class="tab-pane fade in active">
                                <?php echo $item->content; ?>

                            </div>
                        <?php else: ?>
                            <div id="<?php echo e($item->tabId); ?>" class="tab-pane fade">
                                <?php echo $item->content; ?>

                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="row">
                    <div class="col-md-12 right-side-bar">
                        <h3><?php echo trans('string.how_to_buy'); ?></h3>
                        <p><?php echo trans('string.you_can_call'); ?> :</p>
                        <p>(02)2797-7568</p>
                        <p><?php echo trans('string.commissioner_contact'); ?></p>
                    </div>
                    <div class="col-md-12 right-side-bar">
                        <h3><?php echo trans('string.related_products'); ?></h3>
                        <?php $__currentLoopData = ProductView::getByCategory(ProductView::get($guid)->category); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p>
                                <a href="/product/detail/<?php echo e($item->guid); ?>"><?php echo e($item->title); ?></a>
                            </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.product.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>