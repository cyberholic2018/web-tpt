<?php $__env->startSection('custom-style'); ?>
    <style media="screen">
        .page-content-header {
            background-image: url('/images/interior-1944348_960_720.jpg');
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 page-content">
            <div class="page-content-header">
                <h2><?php echo trans('header.bidding_project'); ?></h2>
            </div>
        </div>
    </div>
    <div class="row">
        
        <div class="col-md-8 col-md-offset-2 sub-page-content">
            <?php echo $__env->yieldContent('sub-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>