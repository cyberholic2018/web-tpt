<?php $__env->startSection('custom-js-script'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel-content'); ?>
    <div class="row ch-post-form">
        <div class="col-md-12">
            <table class="table field-table">
                <thead>
                    <tr>
                        <th>夥伴名稱</th>
                        <th>夥伴地址</th>
                        <th>語系</th>
                        <th>夥伴網址</th>
                        <th>座標經度</th>
                        <th>座標緯度</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = PartnerView::admin(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="/cyberholic-system/partner/edit/<?php echo e($item->guid); ?>"><?php echo e($item->name); ?></a>
                            </td>
                            <td><?php echo e($item->addressString); ?></td>
                            <th><?php echo e($item->locale); ?></th>
                            <td><?php echo e($item->link); ?></td>
                            <td><?php echo e($item->longitude); ?></td>
                            <td>
                                <?php echo e($item->latitude); ?>

                            </td>
                            <td><a href="/partner/delete/<?php echo e($item->guid); ?>" onclick="return confirm('確定要刪除此合作夥伴?')">刪除</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>