<?php $__env->startSection('sub-content'); ?>
    

    <br>
    <?php if(ContentView::get(App::getLocale())): ?>
        <h2><?php echo e(ContentView::get(App::getLocale())->title); ?></h2>
    <?php endif; ?>
    <?php if(ContentView::get(App::getLocale())): ?>
        <h3><?php echo e(ContentView::get(App::getLocale())->content); ?></h3>
    <?php endif; ?>


    <hr>
    <ul class="nav nav-tabs">
        <?php $__currentLoopData = $support; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key == 0): ?>
                 <li class="active"><a data-toggle="tab" href="#<?php echo e($value->fileSize.$value->id); ?>"><?php echo e($value->fileName); ?></a></li>
            <?php else: ?>
                 <li><a data-toggle="tab" href="#<?php echo e($value->fileSize.$value->id); ?>"><?php echo e($value->fileName); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="tab-content">
        <?php $__currentLoopData = $support; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key == 0): ?>
                <div id="<?php echo e($value->fileSize.$value->id); ?>" class="tab-pane fade in active">
                    <?php echo $value->description; ?>

                </div>
            <?php else: ?>
                <div id="<?php echo e($value->fileSize.$value->id); ?>" class="tab-pane fade">
                    <?php echo $value->description; ?>

                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.bidding.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>