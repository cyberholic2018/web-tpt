<?php $__env->startSection('custom-js-script'); ?>
<script src="<?php echo e(asset('js/admin-page.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel-content'); ?>
<div class="row" id="adminPage">
    <div class="col-md-12">
        <adminpage></adminpage>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>