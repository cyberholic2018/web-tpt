<table width="500" border="1">
    <tr>
        <td colspan="2">
            <h2>聯繫通知信</h2>
        </td>
    </tr>
    <tr>
        <td>姓名</td>
        <td><?php echo e($name); ?></td>
    </tr>
    <tr>
        <td>E-mail</td>
        <td><?php echo e($email); ?></td>
    </tr>
    <tr>
        <td>電話號碼</td>
        <td><?php echo e($phone); ?></td>
    </tr>
    <tr>
        <td>諮詢項目</td>
        <td><?php echo e($type); ?></td>
    </tr>
    <tr>
        <td>從哪裡得知?</td>
        <td><?php echo e($where); ?></td>
    </tr>
    <tr>
        <td colspan="2">諮詢內容</td>
    </tr>
    <tr>
        <td colspan="2"><?php echo nl2br($content); ?></td>
    </tr>
</table>
