<?php $__env->startSection('sub-content'); ?>
    <table class="table support-table">
        <thead>
            <tr>
                <th align="center" width="30">
                </th>
                <th>
                    File Name
                </th>
                <th style="text-align: center" align="center" width="100">
                    File Size
                </th>
                <th align="center" width="75">
                    Download
                </th>
            </tr>
        </thead>
        <tbody>
            <?php for($i=0; $i < count($support); $i++): ?>
                <tr>
                    <td align="center">#<?php echo e($i + 1); ?></td>
                    <td><?php echo e($support[$i]->fileName); ?></td>
                    <td align="center">
                        <?php if($support[$i]->fileSize < 1024): ?>
                            <?php echo e($support[$i]->fileSize); ?> bytes
                        <?php elseif(($support[$i]->fileSize >= 1024) && ($support[$i]->fileSize < 1048576)): ?>
                            <?php echo e(round($support[$i]->fileSize / 1024, 2)); ?> KB
                        <?php elseif($support[$i]->fileSize >= 1048576): ?>
                            <?php echo e(round($support[$i]->fileSize / 1048576, 2)); ?> MB
                        <?php endif; ?>
                    </td>
                    <td align="center"><a target="_blank" href="<?php echo e($support[$i]->downloadLink); ?>"><span class="glyphicon glyphicon-download-alt"></span></td>
                </tr>
            <?php endfor; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.resource.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>