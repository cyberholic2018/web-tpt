<?php $__env->startSection('custom-js-script'); ?>
    <script src="<?php echo e(asset('js/add-list.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel-content'); ?>
    <div class="row ch-post-form" id="add-list">
        <div class="col-md-12">
            <add-list></add-list>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>