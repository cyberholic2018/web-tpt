<?php $__env->startSection('custom-js-script'); ?>
    <script src="<?php echo e(asset('js/netone-news.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-style'); ?>
    <style media="screen">
        .page-content-header {
            background-image: url('/images/sunrise-1756274_1920.jpg');
        }
        <?php $__currentLoopData = ithome::get(11); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            .ithome0<?php echo e($key); ?> {
                background-image: url('<?php echo e($value['featureImage']); ?>');
            }
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 page-content">
            <div class="page-content-header">
                <h2><?php echo trans('header.news'); ?></h2>
            </div>
        </div>
    </div>
    <div class="row" id="netone-news">
        <div class="col-md-8 col-md-offset-2 about-content" style="margin-top: 30px; margin-bottom: 50px;">
            <br>
            <table class="table-field">
                <?php $__currentLoopData = PostView::news(App::getLocale()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <h4><a href="/news/<?php echo e($item->guid); ?>"><?php echo e($item->title); ?></a></h4>
                        </td>
                        <td align="right">
                            <?php echo date('Y-m-d', strtotime($item->created_at)); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php echo e(PostView::news(App::getLocale())); ?>



        </div>
        <div class="col-md-8 col-md-offset-2">
            <div class="row">
                <?php $__currentLoopData = ithome::get(9); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 news-section news-top">
                        <div class="zoom-bg ithome0<?php echo e($key); ?>"></div>
                        <div class="news-info news-bottom">
                            <h2><a target="_blank" href="<?php echo e($value['link']); ?>"><?php echo e($value['title']); ?></a></h2>
                            <h3 class="hash-tag">#iTHome</h3>
                            <span><?php echo e($value["pubDate"]); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>