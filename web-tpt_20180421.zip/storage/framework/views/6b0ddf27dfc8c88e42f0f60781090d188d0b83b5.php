<?php $__env->startSection('sub-content'); ?>
    <div class="row">
        <?php $__currentLoopData = $currentProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 product-box">
                <div class="product-image">
                    <a href="/product/detail/<?php echo e($item->guid); ?>"><img src="<?php echo e($item->featureImage); ?>"></a>

                </div>
                <div class="product-title">
                    <a href="/product/detail/<?php echo e($item->guid); ?>"><h4><?php echo e($item->title); ?></h4></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.product.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>