<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2 about-content">
            <ul class="about-info">
                <li>
                    <strong>關於我們</strong>
                </li>
            </ul>

            <p>柏策科技NetONE Technology Co.,LTD.成立於2013年，由本公司負責人邀集資訊安全資深高階主管與專業技術人員等專業人士共同打拼, 兼持「優越產品 領先技術」為宗旨.全心投入資訊安全網路設備市場代理銷售的角色，提供網路硬體防火牆設備、IP/MAC網路管理、動態資料遮罩等、軟硬體資訊安全解決方案。致力成為網路整合解決方案全方位資訊安全專業代理商</p>

            <p>「柏策科技」深信透過有效率的團隊合作，秉持「產品、技術、創新、通路、服務」的精神，</p>

            <p>為各大企業徹底解決資訊安全問題，創造彼此雙贏的局面。</p>

            <ul class="about-info">
                <li>
                    <strong>主要營運單位 / 服務項目</strong>
                </li>
            </ul>


            <p>柏策科技以優越的產品、領先的技術、熱忱的服務、永續的研發為經營理念，主要的營運單位如下:</p>

            <p>品牌代理事業部：主要負責資訊安全產品代理及台灣市場銷售與通路建置，並著重專業技術，深耕通路維護與開發。</p>

            <ul class="about-info">
                <li>
                    <strong>新世代資安專業代理商柏策科技</strong>
                </li>
            </ul>


            <p>柏策科技致力於引進「功能比」最優良的產品為代理原則，除協同通路夥伴為各產業的使用者提供高效能的解決方案之外，並提供相關專業資訊安全最佳防護作業準則，專為企業與政府機關提供性價比最佳的資安控管服務及產品；以專業資訊安全最佳防護作業為準則，協同通路夥伴為各產業的使用者提供高效能的解決方案，定位為新產品技術進入產業的最佳專業通路平台，現為Qno，StormShidld台灣代理商.&nbsp;</p>

            <ul class="about-info">
                <li>
                    <strong>資訊安全與最佳專業公司</strong>
                </li>
            </ul>

            <p>在網路犯罪者不斷以日新月異的攻擊手法駭入企業組織裡最弱的環節來竊取各項資訊，以換取不法利益時，企業的營運風險正不斷升高中。在面對新世代資安威脅的現在與未來，柏策科技以【新世代資安專業代理商】自許，將柏策科技豐富的專業經驗，協同通路夥伴，遵循國內外資安相關法規，為企業與機關提供各階段風險控管作業程式的規劃，並建置最適化的防護產品及專業顧問服務，是提供資訊安全專業的全方位公司。</p>

            <div style="text-align: center">
                <img src="images/core_vaule-01.png" width="50%" style="margin: 0 auto" alt="">
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>