<?php $__env->startSection('custom-style'); ?>
    <style media="screen">
        .page-contant-header {
            background-image: url('<?php echo $pageContent->featureImage; ?>');
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="page-contant-header">
                <h2><?php echo e($pageContent->title); ?></h2>
            </div>
            <div class="page-thumbnail">
                <span class="glyphicon glyphicon-home" aria-hidden="true"></span>
                <span>></span>
                <span>Contact Us</span>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <ul class="page-side-menu">
                <li><a class="<?php echo e($active01); ?>" href="/contact">Contact Us</a></li>
                <li><a class="<?php echo e($active02); ?>" href="/contact/taiwanheadquarters">Taiwan Headquarters</a></li>
                <li><a class="<?php echo e($active03); ?>" href="/contact/chinaoperationcentre">China Operation Centre</a></li>
                <li><a class="<?php echo e($active04); ?>" href="/contact/supportnservice">Support & Service</a></li>
                <li><a class="<?php echo e($active05); ?>" href="/contact/salesinquiry">Sales Inquiry</a></li>
                <li><a class="<?php echo e($active06); ?>" href="/contact/jobapplication">Job Application</a></li>
            </ul>
        </div>
        <div class="col-md-9 sub-page-content">
            <?php echo $__env->yieldContent('sub-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>