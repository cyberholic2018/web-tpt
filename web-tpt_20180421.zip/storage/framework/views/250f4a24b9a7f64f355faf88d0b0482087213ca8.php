<?php $__env->startSection('custom-style'); ?>
    <link rel="stylesheet" type="text/css" href="/js/plugins/slider/engine1/style.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js-script'); ?>
    <script type="text/javascript" src="js/plugins/slider/engine1/wowslider.js"></script>
    <script type="text/javascript" src="js/plugins/slider/engine1/script.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12" style="padding: 0; overflow:hidden">
            <div id="wowslider-container1">
                <div class="ws_images">
                    <ul>
                        <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><img src="<?php echo e($item->url); ?>" alt="<?php echo e($item->title); ?>" title="<?php echo e($item->title); ?>"/></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="ws_bullets">
                    <div>
                        <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="#" title="<?php echo e($item->title); ?>"><span><img height="48" src="<?php echo e($item->url); ?>" alt="<?php echo e($item->title); ?>"/>1</span></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="ws_shadow"></div>
            </div>
        </div>

        <div class="container">
            <div class="col-md-4 solution-section">
                <div class="solution-header product">
                </div>
                <div class="solution-info">
                    <h3>產品資訊</h3>
                    <a href="#">找尋您的資安產品</a>
                </div>
            </div>

            <div class="col-md-4 solution-section">
                <div class="solution-header solution">
                </div>
                <div class="solution-info">
                    <h3>解決方案</h3>
                    <a href="#">搭售專屬解決方案</a>
                </div>
            </div>

            <div class="col-md-4 solution-section">
                <div class="solution-header partner">
                </div>
                <div class="solution-info">
                    <h3>合作夥伴</h3>
                    <a href="#">查看我們的合作夥伴</a>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4 news-section">
                    <div class="zoom-bg bg01"></div>
                    <div class="news-info">
                        <h2><a href="#">當心！全球五萬大網站中有482個會記錄您的鍵盤敲擊，滑鼠軌跡。</a></h2>
                        <h3 class="hash-tag">#iTHome</h3>
                        <span>2017.11.05</span>
                    </div>
                </div>
                <div class="col-md-4 news-section">
                    <div class="zoom-bg bg02"></div>
                    <div class="news-info">
                        <h2><a href="#">英特爾修補影響數百萬台PC與伺服器的CPU韌體漏洞。</a></h2>
                        <h3 class="hash-tag">#iTHome</h3>
                        <span>2017.11.03</span>
                    </div>
                </div>
                <div class="col-md-4 news-section">
                    <div class="zoom-bg bg03"></div>
                    <div class="news-info">
                        <h2><a href="#">資安再度成為國家力推的重點產業，行政院長賴清德要求...</a></h2>
                        <h3 class="hash-tag">#iTHome</h3>
                        <span>2017.10.28</span>
                    </div>
                </div>
                <div class="col-md-12 learn-more-news">
                    <a href="#">點選我回顧更多過往新聞</a>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>