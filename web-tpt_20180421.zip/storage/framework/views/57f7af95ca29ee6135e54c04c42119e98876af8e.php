<?php $__env->startSection('custom-js-script'); ?>
    <script src="<?php echo e(asset('js/contact-us.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row" id="contact-us">
        <div class="col-md-8 col-md-offset-2 about-content">
            <div class="mail-sending">
                <img src="/img/icon/loading-bar.svg" alt="">
            </div>
            <h3>聯絡我們</h3>
            <hr>
            <p>填寫以下的表格，以便於隨時與我們聯繫</p>
            <hr>
            <contact-us></contact-us>
        </div>
        <div class="col-md-12" style="padding: 0">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3614.1594550432787!2d121.54003061549417!3d25.06258408395907!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3442abe35a4dce25%3A0x531822931b4ca2cb!2zMTA0OTHlj7DljJfluILkuK3lsbHljYDmsJHmrIrmnbHot6_kuInmrrUzNeiZnw!5e0!3m2!1szh-TW!2stw!4v1504111756068" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>