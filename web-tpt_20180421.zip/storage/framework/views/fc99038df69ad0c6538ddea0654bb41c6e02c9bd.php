<?php $__env->startSection('custom-js-script'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2 about-content">
            <h3>品牌代理</h3>
            <hr>
            <div class="row">
                <div class="col-md-6">
                    <div style="text-align: center">
                        <img src="/images/qno-vector-logo1-1.png" alt="">
                    </div>

                    <p>Qno俠諾科技自2004年創立品牌，以雄厚的研發團隊實力，因應企業頻寬管理需求，率先開發一系列新一代網路安全設備。短短幾年間，已榮獲無數IT大獎的肯定，並迅速成為中小企業心目中最理想的網路設備品牌之一。中國IT影響力媒體大調查，Qno俠諾已連續4年蟬連全中國網路設備關注度前十大品牌之一，是成長速度最快的SMB網路設備廠商。</p>

                    <p>Qno俠諾品牌力求安全(Secure)、快速(Speedy)、簡單(Simple) 3S理念，強調極簡的操作設計風格，可同時兼具快速、安全的網路品質。Qno俠諾秉持3S理念所開發的全系列創新網路技術，已幫助全世界無數企業網管，使用更聰明精簡的方式進行網路管理工作，同時提升企業網路傳輸速度，並加倍企業網路安全防護。</p>

                    <p>原廠網站:<a href="http://www.qno.com.tw">http://www.qno.com.tw</a></p>
                </div>
                <div class="col-md-6">
                    <div style="text-align: center">
                        <img src="/images/Stormshild_logo-01.png" alt="">
                    </div>
                    <p><strong>空中巴士集團</strong>（英語：<strong>Airbus Group</strong>）是一家專門開發、生產及銷售固定翼飛機、旋翼機、運載火箭、導彈和人造衛星等大型航空器的綜合企業集團。註冊於荷蘭萊頓、總部位於法國圖魯茲，旗下為空中巴士公司、空中巴士國防與航天公司和空中巴士直升機公司等公司所組成。</p>

                    <p>空中巴士集團是世界上當今唯二能夠製造大型廣體客機的製造商，也是唯一有能力於民航業界與美國波音公司競爭的企業，在民航機市場上與波音不相上下。同時空中巴士集團也生產諸多軍用機及飛行武器，是全球第七大的國防承包商。前身為歐洲航空國防與航空公司（EADS）。</p>

                    <p>Stormshield是100%全資屬於空中巴士國防與航空公司擁有的資安廠商</p>

                    <p>原廠網站:<a href="https://www.stormshield.com/">https://www.stormshield.com/</a></p>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('netone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>