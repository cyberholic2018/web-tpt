<?php

return [
    'en' => 'English',
    'zh-TW' => '繁體中文',
];
